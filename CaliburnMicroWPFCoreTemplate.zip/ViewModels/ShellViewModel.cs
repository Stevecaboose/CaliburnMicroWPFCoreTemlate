﻿using System;
using System.Collections.Generic;
using System.Text;
using Caliburn.Micro;

namespace CaliburnMicroWPFCoreTemlate.ViewModels
{
    public class ShellViewModel : Screen
    {
    }
}
